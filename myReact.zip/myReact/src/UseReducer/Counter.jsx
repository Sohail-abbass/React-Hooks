import  { useReducer } from "react";
const initialState = {count:0};
import {reducer} from './Reducer';
const Counter = () => {
// first counter function run after get inital state from inital state and then dispatch in counter and then in reducer
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <div style={{background:"white",color:"black", fontSize:"25px", textDecoration:"underline"}}>
      <h1>Count: {state.count}</h1>
      <button style={{border:"2px solid black",marginLeft:"3px"}} onClick={() => dispatch({ type: "increment" })}>Increment</button>
      <button  style={{border:"2px solid black",marginLeft:"3px"}}onClick={() => dispatch({ type: "decrement" })}>Decrement</button>
      <button  style={{border:"2px solid black",marginLeft:"3px"}}onClick={() => dispatch({ type: "reset" })}>Reset</button>
    </div>
  );
};

export default Counter;