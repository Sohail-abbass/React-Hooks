// its a reducer function that is for handling the state with useReducer
export const reducer = (state, action) => {
    switch (action.type) {
      case "increment":
        return { count: state.count + 1};
      case "decrement":
        return { count: state.count - 1 };
      case "reset":
        return { count: 0 };
      default:
        throw new Error("Unknown action type");
    }
  };
  
//   export const initialState = { count: 0 };
  