
// import MyuseState from "./MyuseState"
// import MyuseEffect from "./MyuseEffect"




// import Component from "./UseContext/Component"
// import Contxtprovider from "./UseContext/Contxtprovider"


// import Counter from "./UseReducer/Counter"

// import UseLayout from "./UseLayoutEffect/UseLayout"



// import { UseMomo } from "./UseMemo/UseMomo"





// import UseCallback from "./UseCallback/UseCallback"
// import UseRef from "./UseRef/UseRef"


// import UseTransition from "./UseTransiton/UseTransition"
// import UseDeffered from "./UseDeffered/UseDeffered"
import UseId from "./UseId/UseId"
const App = () => {
  return (
    <div>
      <h1>My App</h1>
       {/* <MyuseState/>
<MyuseEffect/>
<Contxtprovider>
  <Component/>
</Contxtprovider>
<Counter/> */}
{/* <UseLayout/> */}
{/* <UseMomo/> */}
{/* <UseCallback/> */}
{/* <UseRef/> */}
{/* <UseTransition/> */}
{/* <UseDeffered/> */}
<UseId/>
    </div>
  )
}

export default App