// import React from 'react'
import { useState } from "react";
const MyuseState = () => {
  const [count, setCount] = useState(0);
  const [counts, setCounts] = useState(0);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const increment = () => {
    setCount(count + 1);
  };
  const decrement = () => {
    setCounts(counts - 1);
  };
  const reset = () => {
    setCount(0);
    setCounts(0);
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`form submitted successfulty by ${(name, email)}`);
    setName("");
    setEmail("");
  };
  const handle = (e) => {
    setName(e.target.value);
  };
  const handleemail = (e) => {
    setEmail(e.target.value);
  };

  return (
    <>
      <div>
        <h1>Counter App</h1>
        <span>Increment!</span>

        <button onClick={increment}>count :{count}</button>
      </div>
      
      <div>
        <span>decrement!</span>
        <button onClick={decrement}>count :{counts}</button>
      </div>
      <button onClick={reset}>Reset</button>

      <h2>Form Handling</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          name="name"
          value={name}
          onChange={handle}
          placeholder="your name"
        />
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="name"
          name="name"
          value={email}
          onChange={handleemail}
          placeholder="your email"
        />
        <button type="submit">submit</button>
      </form>
    </>
  );
};

export default MyuseState;
