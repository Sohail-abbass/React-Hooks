import { useState, useRef } from 'react';

const UseRef = () => {
  const [count, setCount] = useState(0); // triggers re-render on state change
  const clickCountRef = useRef(0); // does not trigger re-render on update

  const handleClick = () => {
    setCount(count + 1); // Re-renders
    clickCountRef.current += 1; // Does not trigger re-render it track how much count click
    console.log('Button clicked:', clickCountRef.current);
  };

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={handleClick}>Increment</button>
    </div>
  );
};

export default UseRef;
