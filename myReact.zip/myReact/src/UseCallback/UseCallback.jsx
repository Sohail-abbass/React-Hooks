import React, { useState, useCallback } from 'react';

// Child component that receives the increment function as a prop
const ChildComponent = React.memo(({ increment }) => {
  console.log("Child component rendered");
  return (
    <div>
      <button onClick={increment}>Increment in Child</button>
    </div>
  );
});

// Set display name for ChildComponent for debugging purposes
ChildComponent.displayName = 'ChildComponent';

const UseCallback = () => {
  const [count, setCount] = useState(0);

  // Memoizing the increment function using useCallback
  const increment = useCallback(() => {
    setCount((prevCount) => prevCount + 1);
  }, []); // The function reference will not change unless dependencies change

  return (
    <div>
      <h1>Count: {count}</h1>
      <button onClick={increment}>Increment in Parent</button>
      <ChildComponent increment={increment} />
    </div>
  );
};

export default UseCallback;
