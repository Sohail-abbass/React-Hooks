import  { useState,useLayoutEffect } from 'react'

const UseLayout = () => {
    const[num,setNum]=useState(0)
// by useLayouteffect component render before sreen is updated or painted where as by useeffect when we slow the network every update first screen is render then update evey click we got 0 then updated
        useLayoutEffect(() => {
        if(num===0){
       
            setNum(Math.random()+5);
    
        }
        }, [num])
    console.log("hiii");

  return (
    <>
   <p>UseLayout effect</p>
   <h2>{num}</h2>
   <button onClick={()=>setNum(0)}>Check</button>
    </>
  )
}

export default UseLayout