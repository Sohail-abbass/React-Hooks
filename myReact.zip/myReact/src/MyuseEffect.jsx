import { useState, useEffect } from 'react';

const MyuseEffect = () => {
  const [date, setCurrentDate] = useState();

  useEffect(() => {
    console.log("Effect runs once when component mounted because of empty dependency array");

    // Setting up an interval that updates the date every second
    const interval = setInterval(() => {
      const newDate = new Date();
      setCurrentDate(newDate.toLocaleTimeString());
      
      // Logs every second as the state updates
      console.log("renders");
    }, 1000);

    // Cleanup function that runs when the component unmounts
    return () => {
      console.log("Cleanup: Clearing the interval");
      clearInterval(interval); // Clears the interval when the component unmounts
    };
  }, []); // Empty dependency array: useEffect runs once when component mounts

  // Logs every time the component re-renders
  console.log("Component re-rendered");

  return (
    <>
      <h1>Use-Effect Hook</h1>
      <h2>Current date</h2>
      <p>{date}</p>
    </>
  );
};

export default MyuseEffect;

// initial mount first log effects runs one and re render then evey second render then rerenderd