 export function UseMomo() {
    const cache = {}; // Cache to store 
  
    return function (num) {
      if (cache[num] !== undefined) {
        console.log("Fetching from cache...");
        return cache[num];
      }
  
      console.log("Computing...");
      const result = num * num;
      cache[num] = result; // Store the result in the cache
      return result;
    };
  }
  
  const memoizedFunc = UseMomo();
  
  console.log(memoizedFunc(5)); // "Computing..." 25
  console.log(memoizedFunc(5)); // "Fetching from cache..." 25
  



//   Without memo
// //   function slowFunction(num) {
//   console.log("Computing...");
//   return num * num;
// }

// console.log(slowFunction(5)); // "Computing..." 25
// console.log(slowFunction(5)); // "Computing..." 25
