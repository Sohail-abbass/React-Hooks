import  { useState, useDeferredValue, useEffect } from 'react';

const UseDeffered = () => {
  const [query, setQuery] = useState('');
  const deferredQuery = useDeferredValue(query);  // Deferred query state

  const names = ['Sohail', 'Noman', 'Saad', 'TOuqeer', 'Saif', 'Afzal', 'ABdullal'];

  const [filteredItems, setFilteredItems] = useState([]);

  // Simulate an expensive filtering operation
  useEffect(() => {
    const result = names.filter(name => name.toLowerCase().includes(deferredQuery.toLowerCase()));
    setFilteredItems(result);
  }, [deferredQuery]);  // Only run the filter when deferredQuery changes

  return (
    <div>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)} // Updates `query` immediately
        placeholder="Search name of person..."
      />
      <ul>
        {filteredItems.map((name, index) => (
          <li key={index}>{name}</li>
        ))}
      </ul>
    </div>
  );
};

export default UseDeffered;
