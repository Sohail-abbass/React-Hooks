
import { useContext } from 'react'
import { ThemeContext } from './UseContext'

const Component = () => {
    const { theme, toggle } = useContext(ThemeContext);

    return (
        <>

     
      <div
    //   <p></p>
        style={{
          backgroundColor: theme === "light" ? "#fff" : "#333",
          color: theme === "light" ? "#000" : "#fff",
          minHeight: "70vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          width:"700px",
          border:"2px solid brown"
        }}
      >
        <h1>{`Current Theme: ${theme}`}</h1>
        <button
          onClick={toggle}
          style={{
           
            padding: "10px 20px",
            marginTop: "20px",
            backgroundColor: theme === "light" ? "#000" : "#fff",
            color: theme === "light" ? "#fff" : "#000",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Toggle Theme
        </button>
      </div>
      </>
    );
}

export default Component;