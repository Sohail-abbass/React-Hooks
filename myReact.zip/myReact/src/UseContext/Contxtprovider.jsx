
import { useState } from "react";
import { ThemeContext } from "./UseContext";
// import React from 'react'


const Contxtprovider = ({children}) => {
    
    const [theme,setTheme]=useState("light")
    const toggle=()=>{
        setTheme(theme==="light"?"dark":"light")
    }
  return (
    <div>
        <ThemeContext.Provider value={{theme,toggle}}>
            {children}
        </ThemeContext.Provider>
    </div>
  )
}

export default Contxtprovider