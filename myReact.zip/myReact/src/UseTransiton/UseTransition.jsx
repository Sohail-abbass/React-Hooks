import { useState, useTransition } from 'react';

const UseTransition = () => {
  const [isPending, startTransition] = useTransition();
  const [count, setCount] = useState(0);
  const [text, setText] = useState('');

  const handleTextChange = (e) => {
    startTransition(() => {
      setText(e.target.value);
    });
  };

  const handleCountChange = () => {
    setCount(count + 1); // This is an urgent update
  };

  return (
    <div>
      <h1>Count: {count}</h1>
      <button onClick={handleCountChange}>Increment Count</button>
      <input 
        type="text"
        value={text}
        onChange={handleTextChange} // Handles text input with transition
      />
      {isPending && <p>Updating...</p>}
    </div>
  );
};

export default UseTransition;
